﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;


namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\kvalificacia.mdf;Integrated Security=True;Connect Timeout=30";
        int Id = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            LoadData3();
            // TODO: данная строка кода позволяет загрузить данные в таблицу "kvalificaciaDataSet1.rezultat". При необходимости она может быть перемещена или удалена.
            this.rezultatTableAdapter.Fill(this.kvalificaciaDataSet1.rezultat);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "kvalificaciaDataSet1.rezultat". При необходимости она может быть перемещена или удалена.
            this.rezultatTableAdapter.Fill(this.kvalificaciaDataSet1.rezultat);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "kvalificaciaDataSet.rezultat". При необходимости она может быть перемещена или удалена.

            // TODO: данная строка кода позволяет загрузить данные в таблицу "kvalificaciaDataSet.ychitelya". При необходимости она может быть перемещена или удалена.
            this.ychitelyaTableAdapter.Fill(this.kvalificaciaDataSet.ychitelya);

        }
        private void LoadData3()
        {
           
            // Запрос к базе данных
            string query = "SELECT* FROM[dbo].[rezultat] ";

            // Подключение к базе данных и заполнение DataTable
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter dataAdapter = new SqlDataAdapter(query, connection);
                DataTable dataTable = new DataTable();
                dataAdapter.Fill(dataTable);

                // Привязка данных к DataGridView
                dataGridView2.DataSource = dataTable;

                // Скрытие столбца id
                if (dataGridView2.Columns["id"] != null)
                {
                    dataGridView2.Columns["id"].Visible = false;
                }
            }
        }
        private void LoadData()
        {
            string query = "SELECT * FROM [dbo].[ychitelya]";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter dataAdapter = new SqlDataAdapter(query, connection);
                System.Data.DataTable dataTable = new System.Data.DataTable();
                dataAdapter.Fill(dataTable);
                dataGridView1.DataSource = dataTable;


            }
        }
        private void LoadData2()
        {
            string query = "SELECT * FROM [dbo].[rezultat]";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter dataAdapter = new SqlDataAdapter(query, connection);
                System.Data.DataTable dataTable = new System.Data.DataTable();
                dataAdapter.Fill(dataTable);
                dataGridView2.DataSource = dataTable;


            }
        }
        private void addbutton_Click(object sender, EventArgs e)
        {
            // Получение данных из текстовых полей
            string imya = textBox1.Text;
            string familya = textBox2.Text;
            string otchestvo = textBox3.Text;


            // SQL-запрос для вставки данных (без Id, так как он генерируется автоматически)
            string query = "INSERT INTO [dbo].[ychitelya] (imya, familya, otchestvo) VALUES (@imya, @familya, @otchestvo)";

            // Создание соединения с базой данных и команды для выполнения запроса
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);

                // Параметры запроса
                command.Parameters.AddWithValue("@imya", imya);
                command.Parameters.AddWithValue("@familya", familya);
                command.Parameters.AddWithValue("@otchestvo", otchestvo);


                // Открытие соединения и выполнение запроса
                try
                {
                    connection.Open();
                    command.ExecuteNonQuery();
                    MessageBox.Show("Данные успешно добавлены!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка при добавлении данных: " + ex.Message);
                }
                LoadData();
            }
        }

        private void dataGridView1_DoubleClick(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow.Index != -1)
            {
                Id = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value.ToString());
                textBox1.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
                textBox2.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
                textBox3.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();

            }
        }

        private void deletebutton_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {

                string query = "DELETE FROM [dbo].[ychitelya] WHERE Id = @Id";
                // Создание соединения с базой данных и команды для выполнения запроса
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);

                    // Параметры запроса
                    command.Parameters.AddWithValue("@Id", Id);

                    // Открытие соединения и выполнение запроса
                    try
                    {
                        connection.Open();
                        command.ExecuteNonQuery();
                        MessageBox.Show("Данные успешно удалены!");
                        LoadData(); // Обновление данных после удаления
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Ошибка при удалении данных: " + ex.Message);
                    }
                }
            }
        }

        private void exportbutton_Click(object sender, EventArgs e)
        {
            Microsoft.Office.Interop.Excel.Application ExcelApp = new Microsoft.Office.Interop.Excel.Application();
            Microsoft.Office.Interop.Excel.Workbook ExcelWorkBook;
            Microsoft.Office.Interop.Excel.Worksheet ExcelWorkSheet;
            // Создаем новую книгу Excel
            ExcelWorkBook = ExcelApp.Workbooks.Add(System.Reflection.Missing.Value);

            // Создаем лист Excel
            ExcelWorkSheet = (Microsoft.Office.Interop.Excel.Worksheet)ExcelWorkBook.Worksheets.get_Item(1);
            for (int i = 1; i <= dataGridView1.Columns.Count; i++)
            {
                ExcelWorkSheet.Cells[1, i] = dataGridView1.Columns[i - 1].HeaderText;
            }

            // Записываем данные из DataGridView
            for (int i = 0; i < dataGridView1.Rows.Count; i++)
            {
                for (int j = 0; j < dataGridView1.Columns.Count; j++)
                {
                    ExcelApp.Cells[i + 1, j + 1] = dataGridView1.Rows[i].Cells[j].Value;

                }
            }

            // Сохраняем книгу Excel
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Excel files (*.xlsx)|*.xlsx|All files (*.*)|*.*";
            saveFileDialog.FilterIndex = 2;
            saveFileDialog.RestoreDirectory = true;

            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                ExcelWorkBook.SaveAs(saveFileDialog.FileName);
                MessageBox.Show("Данные успешно сохранены в файле " + saveFileDialog.FileName);
            }

            // Закрываем приложение Excel
            ExcelApp.Quit();
            ExcelWorkBook = null;
            ExcelApp = null;
        }

        private void searchbox_TextChanged(object sender, EventArgs e)
        {
            string searchQuery = searchbox.Text;

            string query = "SELECT * FROM [dbo].[ychitelya] WHERE imya LIKE @searchQuery";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter dataAdapter = new SqlDataAdapter(query, connection);
                dataAdapter.SelectCommand.Parameters.AddWithValue("@searchQuery", "%" + searchQuery + "%");
                System.Data.DataTable dataTable = new System.Data.DataTable();
                dataAdapter.Fill(dataTable);
                dataGridView1.DataSource = dataTable;
            }
        }

        private void dobavit_Click(object sender, EventArgs e)
        {
            // Получение данных из текстовых полей
            string imya = comboBox1.Text;
            string familiya = comboBox2.Text;
            string rezultat = textBox4.Text;


            // SQL-запрос для вставки данных (без Id, так как он генерируется автоматически)
            string query = "INSERT INTO [dbo].[rezultat] (imyauchitelya, familiya, rezultat) VALUES (@imyauchitelya, @familiya, @rezultat)";

            // Создание соединения с базой данных и команды для выполнения запроса
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);

                // Параметры запроса
                command.Parameters.AddWithValue("@imyauchitelya", imya);
                command.Parameters.AddWithValue("@familiya", familiya);
                command.Parameters.AddWithValue("@rezultat", rezultat);


                // Открытие соединения и выполнение запроса
                try
                {
                    connection.Open();
                    command.ExecuteNonQuery();
                    MessageBox.Show("Данные успешно добавлены!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка при добавлении данных: " + ex.Message);
                }
                LoadData2();
            }
        }

        private void export_Click(object sender, EventArgs e)
        {
            Microsoft.Office.Interop.Excel.Application ExcelApp = new Microsoft.Office.Interop.Excel.Application();
            Microsoft.Office.Interop.Excel.Workbook ExcelWorkBook;
            Microsoft.Office.Interop.Excel.Worksheet ExcelWorkSheet;
            // Создаем новую книгу Excel
            ExcelWorkBook = ExcelApp.Workbooks.Add(System.Reflection.Missing.Value);

            // Создаем лист Excel
            ExcelWorkSheet = (Microsoft.Office.Interop.Excel.Worksheet)ExcelWorkBook.Worksheets.get_Item(1);
            for (int i = 1; i <= dataGridView2.Columns.Count; i++)
            {
                ExcelWorkSheet.Cells[1, i] = dataGridView2.Columns[i - 1].HeaderText;
            }

            // Записываем данные из DataGridView
            for (int i = 0; i < dataGridView2.Rows.Count; i++)
            {
                for (int j = 0; j < dataGridView2.Columns.Count; j++)
                {
                    ExcelApp.Cells[i + 1, j + 1] = dataGridView2.Rows[i].Cells[j].Value;

                }
            }

            // Сохраняем книгу Excel
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Excel files (*.xlsx)|*.xlsx|All files (*.*)|*.*";
            saveFileDialog.FilterIndex = 2;
            saveFileDialog.RestoreDirectory = true;

            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                ExcelWorkBook.SaveAs(saveFileDialog.FileName);
                MessageBox.Show("Данные успешно сохранены в файле " + saveFileDialog.FileName);
            }

            // Закрываем приложение Excel
            ExcelApp.Quit();
            ExcelWorkBook = null;
            ExcelApp = null;
        }

        private void udalit_Click(object sender, EventArgs e)
        {
            if (dataGridView2.SelectedRows.Count > 0)
            {

                string query = "DELETE FROM [dbo].[rezultat] WHERE Id = @Id";
                // Создание соединения с базой данных и команды для выполнения запроса
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);

                    // Параметры запроса
                    command.Parameters.AddWithValue("@Id", Id);

                    // Открытие соединения и выполнение запроса
                    try
                    {
                        connection.Open();
                        command.ExecuteNonQuery();
                        MessageBox.Show("Данные успешно удалены!");
                        LoadData2(); // Обновление данных после удаления
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Ошибка при удалении данных: " + ex.Message);
                    }
                }
            }
        }

        private void dataGridView2_DoubleClick(object sender, EventArgs e)
        {
            if (dataGridView2.CurrentRow.Index != -1)
            {
                Id = Convert.ToInt32(dataGridView2.CurrentRow.Cells[0].Value.ToString());
                comboBox1.Text = dataGridView2.CurrentRow.Cells[1].Value.ToString();
                comboBox2.Text = dataGridView2.CurrentRow.Cells[2].Value.ToString();
                textBox3.Text = dataGridView2.CurrentRow.Cells[3].Value.ToString();

            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            string searchQuery = textBox5.Text;

            string query = "SELECT * FROM [dbo].[rezultat] WHERE imyauchitelya LIKE @searchQuery";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter dataAdapter = new SqlDataAdapter(query, connection);
                dataAdapter.SelectCommand.Parameters.AddWithValue("@searchQuery", "%" + searchQuery + "%");
                System.Data.DataTable dataTable = new System.Data.DataTable();
                dataAdapter.Fill(dataTable);
                dataGridView2.DataSource = dataTable;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string query = "SELECT * FROM [dbo].[rezultat]";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter dataAdapter = new SqlDataAdapter(query, connection);
                DataTable dataTable = new DataTable();
                dataAdapter.Fill(dataTable);

                // Очистка существующих данных диаграммы
                ZaGodchart.Series.Clear();
                Series series = new Series("rezultat")
                {
                    ChartType = SeriesChartType.Column
                };
                ZaGodchart.Series.Add(series);

                // Установка меток по оси X
                ZaGodchart.ChartAreas[0].AxisX.LabelStyle.Interval = 1;
                ZaGodchart.ChartAreas[0].AxisX.LabelStyle.Angle = -45; 

                // Заполнение диаграммы данными из DataTable
                foreach (DataRow row in dataTable.Rows)
                {
                    string xLabel = row.Field<string>("imyauchitelya"); 
                    decimal? yValue = row.Field<decimal?>("rezultat");
                    if (yValue.HasValue)
                    {
                        int pointIndex = ZaGodchart.Series["rezultat"].Points.AddXY(xLabel, yValue.Value);
                        ZaGodchart.Series["rezultat"].Points[pointIndex].AxisLabel = xLabel;
                    }
                }
            }
        }
    }
}
    

    






