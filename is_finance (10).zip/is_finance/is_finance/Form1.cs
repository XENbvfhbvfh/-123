﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;


namespace is_finance
{
    public partial class Form1 : Form
    {
        // Строка подключения к базе данных
        public string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\finance.mdf;Integrated Security=True;Connect Timeout=30";
        int Id = 0;
        public Form1()
        {
            InitializeComponent();
        }
        private void LoadData()
        {
            string query = "SELECT * FROM [dbo].[Table]";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter dataAdapter = new SqlDataAdapter(query, connection);
                System.Data.DataTable dataTable = new System.Data.DataTable();
                dataAdapter.Fill(dataTable);
                dataGridView1.DataSource = dataTable;


            }
        }
        //обновление диаграммы за год
        private void UpdateChartData2()
        {
            string query = "SELECT * FROM [dbo].[Table]";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter dataAdapter = new SqlDataAdapter(query, connection);
                DataTable dataTable = new DataTable();
                dataAdapter.Fill(dataTable);

                // Очистка существующих данных диаграммы
                ZaGodchart.Series.Clear();
                Series series = new Series("ZA GOD")
                {
                    ChartType = SeriesChartType.Column
                };
                ZaGodchart.Series.Add(series);

                // Установка меток по оси X
                ZaGodchart.ChartAreas[0].AxisX.LabelStyle.Interval = 1;
                ZaGodchart.ChartAreas[0].AxisX.LabelStyle.Angle = -45; // Для поворота меток, если они длинные

                // Заполнение диаграммы данными из DataTable
                foreach (DataRow row in dataTable.Rows)
                {
                    string xLabel = row.Field<string>("predpriyatie"); // Использование predpriyatie как метки по оси X
                    decimal? yValue = row.Field<decimal?>("ZA GOD");
                    if (yValue.HasValue)
                    {
                        int pointIndex = ZaGodchart.Series["ZA GOD"].Points.AddXY(xLabel, yValue.Value);
                        ZaGodchart.Series["ZA GOD"].Points[pointIndex].AxisLabel = xLabel;
                    }
                }
            }
        }
        
        //обновление диаграммы за месяц
        private void UpdateChartData()
        {

            string query = "SELECT * FROM [dbo].[Table]";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter dataAdapter = new SqlDataAdapter(query, connection);
                DataTable dataTable = new DataTable();
                dataAdapter.Fill(dataTable);

                // Очистка существующих данных диаграммы
                ZaMesyatsChart.Series.Clear();
                Series series = new Series("ZA Mesyats")
                {
                    ChartType = SeriesChartType.Column
                };
                ZaMesyatsChart.Series.Add(series);

                // Установка меток по оси X
                ZaMesyatsChart.ChartAreas[0].AxisX.LabelStyle.Interval = 1;
                ZaMesyatsChart.ChartAreas[0].AxisX.LabelStyle.Angle = -45; // Для поворота меток, если они длинные

                // Заполнение диаграммы данными из DataTable
                foreach (DataRow row in dataTable.Rows)
                {
                    string xLabel = row.Field<string>("predpriyatie"); // Использование predpriyatie как метки по оси X
                    decimal? yValue = row.Field<decimal?>("ZA Mesyats");
                    if (yValue.HasValue)
                    {
                        int pointIndex = ZaMesyatsChart.Series["ZA Mesyats"].Points.AddXY(xLabel, yValue.Value);
                        ZaMesyatsChart.Series["ZA Mesyats"].Points[pointIndex].AxisLabel = xLabel;
                    }
                }
            }
        }
    

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "financeDataSet.Table". При необходимости она может быть перемещена или удалена.
            this.tableTableAdapter.Fill(this.financeDataSet.Table);
           
        }

        private void addButton_Click(object sender, EventArgs e)
        {
            // Получение данных из текстовых полей
            string predpriyatie = predpriyatieTextBox.Text;
            decimal zaGod = decimal.Parse(zaGodTextBox.Text);
            decimal zaMesyats = decimal.Parse(zaMesyatsTextBox.Text);

            // SQL-запрос для вставки данных (без Id, так как он генерируется автоматически)
            string query = "INSERT INTO [dbo].[Table] (predpriyatie, [ZA GOD], [ZA Mesyats]) VALUES (@predpriyatie, @zaGod, @zaMesyats)";

            // Создание соединения с базой данных и команды для выполнения запроса
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);

                // Параметры запроса
                command.Parameters.AddWithValue("@predpriyatie", predpriyatie);
                command.Parameters.AddWithValue("@zaGod", zaGod);
                command.Parameters.AddWithValue("@zaMesyats", zaMesyats);

                // Открытие соединения и выполнение запроса
                try
                {
                    connection.Open();
                    command.ExecuteNonQuery();
                    MessageBox.Show("Данные успешно добавлены!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка при добавлении данных: " + ex.Message);
                }
                LoadData();
            }
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            string searchQuery = textBox4.Text;

            string query = "SELECT * FROM [dbo].[Table] WHERE predpriyatie LIKE @searchQuery";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter dataAdapter = new SqlDataAdapter(query, connection);
                dataAdapter.SelectCommand.Parameters.AddWithValue("@searchQuery", "%" + searchQuery + "%");
                System.Data.DataTable dataTable = new System.Data.DataTable();
                dataAdapter.Fill(dataTable);
                dataGridView1.DataSource = dataTable;
            }
        }

        private void Deletebutton_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
               
                string query = "DELETE FROM [dbo].[Table] WHERE Id = @Id";
                // Создание соединения с базой данных и команды для выполнения запроса
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);

                    // Параметры запроса
                    command.Parameters.AddWithValue("@Id", Id);

                    // Открытие соединения и выполнение запроса
                    try
                    {
                        connection.Open();
                        command.ExecuteNonQuery();
                        MessageBox.Show("Данные успешно удалены!");
                        LoadData(); // Обновление данных после удаления
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Ошибка при удалении данных: " + ex.Message);
                    }
                }
            }
        }

        private void dataGridView1_DoubleClick(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow.Index != -1)
            {
                Id = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value.ToString());
                predpriyatieTextBox.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
                zaGodTextBox.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
                zaMesyatsTextBox.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();

            }
        }

        private void Exportbutton_Click(object sender, EventArgs e)
        {
            Microsoft.Office.Interop.Excel.Application ExcelApp = new Microsoft.Office.Interop.Excel.Application();
            Microsoft.Office.Interop.Excel.Workbook ExcelWorkBook;
            Microsoft.Office.Interop.Excel.Worksheet ExcelWorkSheet;
            // Создаем новую книгу Excel
            ExcelWorkBook = ExcelApp.Workbooks.Add(System.Reflection.Missing.Value);

            // Создаем лист Excel
            ExcelWorkSheet = (Microsoft.Office.Interop.Excel.Worksheet)ExcelWorkBook.Worksheets.get_Item(1);
            for (int i = 1; i <= dataGridView1.Columns.Count; i++)
            {
                ExcelWorkSheet.Cells[1, i] = dataGridView1.Columns[i - 1].HeaderText;
            }

            // Записываем данные из DataGridView
            for (int i = 0; i < dataGridView1.Rows.Count; i++)
            {
                for (int j = 0; j < dataGridView1.Columns.Count; j++)
                {
                    ExcelApp.Cells[i + 1, j + 1] = dataGridView1.Rows[i].Cells[j].Value;

                }
            }

            // Сохраняем книгу Excel
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Excel files (*.xlsx)|*.xlsx|All files (*.*)|*.*";
            saveFileDialog.FilterIndex = 2;
            saveFileDialog.RestoreDirectory = true;

            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                ExcelWorkBook.SaveAs(saveFileDialog.FileName);
                MessageBox.Show("Данные успешно сохранены в файле " + saveFileDialog.FileName);
            }

            // Закрываем приложение Excel
            ExcelApp.Quit();
            ExcelWorkBook = null;
            ExcelApp = null;
        }

        private void UpdateButton_Click(object sender, EventArgs e)
        {
            UpdateChartData2();
        }

        private void update_Click(object sender, EventArgs e)
        {
            UpdateChartData();
        }

        private void chart1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            employers employers = new employers();
            employers.ShowDialog();
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("C:\\Windows\\System32\\calc.exe");
        }
    }
 }



