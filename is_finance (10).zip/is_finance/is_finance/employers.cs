﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace is_finance
{
    public partial class employers : Form
    {

        // Строка подключения к базе данных
        public string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\finance.mdf;Integrated Security=True;Connect Timeout=30";
        int Id = 0;
        public employers()
        {
            InitializeComponent();
        }

        private void employers_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "financeDataSet1._1Table". При необходимости она может быть перемещена или удалена.
            this._1TableTableAdapter.Fill(this.financeDataSet1._1Table);

        }

        private void LoadData()
        {
            string query = "SELECT * FROM [dbo].[1Table]";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter dataAdapter = new SqlDataAdapter(query, connection);
                System.Data.DataTable dataTable = new System.Data.DataTable();
                dataAdapter.Fill(dataTable);
                dataGridView1.DataSource = dataTable;


            }
        }
        private void addButton_Click(object sender, EventArgs e)
        {
            // Получение данных из текстовых полей
            string imyaSotrudnika = imyaTextBox.Text;
            string familyaSotrudnika = familyaTextBox.Text;
            string otchestvoSotrudnika = otchestvoTextBox.Text;
            decimal zaGod = decimal.Parse(zaGodTextBox.Text);
            decimal zaMesyats = decimal.Parse(zaMesyatsTextBox.Text);

            // SQL-запрос для вставки данных (без Id, так как он генерируется автоматически)
            string query = "INSERT INTO [dbo].[1Table] (imyasotrudnika, familyasotrudnika, otchestvosotrudnika, [ZA GOD], [ZA Mesyats]) VALUES (@imyaSotrudnika, @familyaSotrudnika, @otchestvoSotrudnika, @zaGod, @zaMesyats)";

            // Создание соединения с базой данных и команды для выполнения запроса
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);

                // Параметры запроса
                command.Parameters.AddWithValue("@imyaSotrudnika", imyaSotrudnika);
                command.Parameters.AddWithValue("@familyaSotrudnika", familyaSotrudnika);
                command.Parameters.AddWithValue("@otchestvoSotrudnika", otchestvoSotrudnika);
                command.Parameters.AddWithValue("@zaGod", zaGod);
                command.Parameters.AddWithValue("@zaMesyats", zaMesyats);

                // Открытие соединения и выполнение запроса
                try
                {
                    connection.Open();
                    command.ExecuteNonQuery();
                    MessageBox.Show("Данные успешно добавлены!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка при добавлении данных: " + ex.Message);
                }
                LoadData();
            }
        }

        private void employers_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Close();
            Form1 form1 = new Form1();
            form1.Show();
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            string searchQuery = textBox4.Text;

            string query = "SELECT * FROM [dbo].[1Table] WHERE imyasotrudnika LIKE @searchQuery";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter dataAdapter = new SqlDataAdapter(query, connection);
                dataAdapter.SelectCommand.Parameters.AddWithValue("@searchQuery", "%" + searchQuery + "%");
                System.Data.DataTable dataTable = new System.Data.DataTable();
                dataAdapter.Fill(dataTable);
                dataGridView1.DataSource = dataTable;
            }
        }

        private void dataGridView1_DoubleClick(object sender, EventArgs e)
        {
                if (dataGridView1.CurrentRow.Index != -1)
                {
                    Id = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value.ToString());
                    imyaTextBox.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
                    familyaTextBox.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
                    otchestvoTextBox.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
                    zaGodTextBox.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
                    zaMesyatsTextBox.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();

                }
        }
        private void UpdateChartData2()
        {
            string query = "SELECT * FROM [dbo].[1Table]";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter dataAdapter = new SqlDataAdapter(query, connection);
                DataTable dataTable = new DataTable();
                dataAdapter.Fill(dataTable);

                // Очистка существующих данных диаграммы
                ZaGodchart.Series.Clear();
                Series series = new Series("ZA GOD")
                {
                    ChartType = SeriesChartType.Column
                };
                ZaGodchart.Series.Add(series);

                // Установка меток по оси X
                ZaGodchart.ChartAreas[0].AxisX.LabelStyle.Interval = 1;
                ZaGodchart.ChartAreas[0].AxisX.LabelStyle.Angle = -45; // Для поворота меток, если они длинные

                // Заполнение диаграммы данными из DataTable
                foreach (DataRow row in dataTable.Rows)
                {
                    string xLabel = row.Field<string>("imyasotrudnika"); // Использование imyasotrudnika как метки по оси X
                    decimal? yValue = row.Field<decimal?>("ZA GOD");
                    if (yValue.HasValue)
                    {
                        int pointIndex = ZaGodchart.Series["ZA GOD"].Points.AddXY(xLabel, yValue.Value);
                        ZaGodchart.Series["ZA GOD"].Points[pointIndex].AxisLabel = xLabel;
                    }
                }
            }
        }
        private void Deletebutton_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {

                string query = "DELETE FROM [dbo].[1Table] WHERE Id = @Id";
                // Создание соединения с базой данных и команды для выполнения запроса
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(query, connection);

                    // Параметры запроса
                    command.Parameters.AddWithValue("@Id", Id);

                    // Открытие соединения и выполнение запроса
                    try
                    {
                        connection.Open();
                        command.ExecuteNonQuery();
                        MessageBox.Show("Данные успешно удалены!");
                        LoadData(); // Обновление данных после удаления
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Ошибка при удалении данных: " + ex.Message);
                    }
                }
            }
        }

        private void Exportbutton_Click(object sender, EventArgs e)
        {
            Microsoft.Office.Interop.Excel.Application ExcelApp = new Microsoft.Office.Interop.Excel.Application();
            Microsoft.Office.Interop.Excel.Workbook ExcelWorkBook;
            Microsoft.Office.Interop.Excel.Worksheet ExcelWorkSheet;
            // Создаем новую книгу Excel
            ExcelWorkBook = ExcelApp.Workbooks.Add(System.Reflection.Missing.Value);

            // Создаем лист Excel
            ExcelWorkSheet = (Microsoft.Office.Interop.Excel.Worksheet)ExcelWorkBook.Worksheets.get_Item(1);
            for (int i = 1; i <= dataGridView1.Columns.Count; i++)
            {
                ExcelWorkSheet.Cells[1, i] = dataGridView1.Columns[i - 1].HeaderText;
            }

            // Записываем данные из DataGridView
            for (int i = 0; i < dataGridView1.Rows.Count; i++)
            {
                for (int j = 0; j < dataGridView1.Columns.Count; j++)
                {
                    ExcelApp.Cells[i + 1, j + 1] = dataGridView1.Rows[i].Cells[j].Value;

                }
            }

            // Сохраняем книгу Excel
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Excel files (*.xlsx)|*.xlsx|All files (*.*)|*.*";
            saveFileDialog.FilterIndex = 2;
            saveFileDialog.RestoreDirectory = true;

            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                ExcelWorkBook.SaveAs(saveFileDialog.FileName);
                MessageBox.Show("Данные успешно сохранены в файле " + saveFileDialog.FileName);
            }

            // Закрываем приложение Excel
            ExcelApp.Quit();
            ExcelWorkBook = null;
            ExcelApp = null;
        }

        private void UpdateButton_Click(object sender, EventArgs e)
        {
            UpdateChartData2();
        }
        private void UpdateChartData()
        {

            string query = "SELECT * FROM [dbo].[1Table]";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlDataAdapter dataAdapter = new SqlDataAdapter(query, connection);
                DataTable dataTable = new DataTable();
                dataAdapter.Fill(dataTable);

                // Очистка существующих данных диаграммы
                ZaMesyatsChart.Series.Clear();
                Series series = new Series("ZA Mesyats")
                {
                    ChartType = SeriesChartType.Column
                };
                ZaMesyatsChart.Series.Add(series);

                // Установка меток по оси X
                ZaMesyatsChart.ChartAreas[0].AxisX.LabelStyle.Interval = 1;
                ZaMesyatsChart.ChartAreas[0].AxisX.LabelStyle.Angle = -45; // Для поворота меток, если они длинные

                // Заполнение диаграммы данными из DataTable
                foreach (DataRow row in dataTable.Rows)
                {
                    string xLabel = row.Field<string>("imyasotrudnika"); // Использование predpriyatie как метки по оси X
                    decimal? yValue = row.Field<decimal?>("ZA Mesyats");
                    if (yValue.HasValue)
                    {
                        int pointIndex = ZaMesyatsChart.Series["ZA Mesyats"].Points.AddXY(xLabel, yValue.Value);
                        ZaMesyatsChart.Series["ZA Mesyats"].Points[pointIndex].AxisLabel = xLabel;
                    }
                }
            }
        }
        private void update_Click(object sender, EventArgs e)
        {
            UpdateChartData();
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("C:\\Windows\\System32\\calc.exe");
        }
    }
}

