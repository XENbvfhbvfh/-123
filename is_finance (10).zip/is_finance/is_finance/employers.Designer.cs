﻿namespace is_finance
{
    partial class employers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea4 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend4 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series4 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea3 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend3 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(employers));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.UpdateButton = new System.Windows.Forms.Button();
            this.ZaGodchart = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.tableBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.financeDataSet1 = new is_finance.financeDataSet1();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.update = new System.Windows.Forms.Button();
            this.ZaMesyatsChart = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.idDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.imyasotrudnikaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.familyasotrudnikaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.otchestvosotrudnikaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.zAGODDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.zAMesyatsDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.otchestvoTextBox = new System.Windows.Forms.TextBox();
            this.familyaTextBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.Exportbutton = new System.Windows.Forms.Button();
            this.Deletebutton = new System.Windows.Forms.Button();
            this.addButton = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.zaMesyatsTextBox = new System.Windows.Forms.TextBox();
            this.zaGodTextBox = new System.Windows.Forms.TextBox();
            this.imyaTextBox = new System.Windows.Forms.TextBox();
            this._1TableTableAdapter = new is_finance.financeDataSet1TableAdapters._1TableTableAdapter();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.tableBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.chart2 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ZaGodchart)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tableBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.financeDataSet1)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ZaMesyatsChart)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tableBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart2)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(13, 263);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1010, 374);
            this.tabControl1.TabIndex = 6;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.chart2);
            this.tabPage1.Controls.Add(this.UpdateButton);
            this.tabPage1.Controls.Add(this.ZaGodchart);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1002, 348);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Диаграмма за год";
            this.tabPage1.UseVisualStyleBackColor = true;
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // UpdateButton
            // 
            this.UpdateButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.UpdateButton.Location = new System.Drawing.Point(918, 318);
            this.UpdateButton.Name = "UpdateButton";
            this.UpdateButton.Size = new System.Drawing.Size(82, 23);
            this.UpdateButton.TabIndex = 1;
            this.UpdateButton.Text = "Обновить";
            this.UpdateButton.UseVisualStyleBackColor = true;
            this.UpdateButton.Click += new System.EventHandler(this.UpdateButton_Click);
            // 
            // ZaGodchart
            // 
            chartArea2.Name = "ChartArea1";
            this.ZaGodchart.ChartAreas.Add(chartArea2);
            this.ZaGodchart.DataSource = this.tableBindingSource;
            legend2.Name = "Legend1";
            this.ZaGodchart.Legends.Add(legend2);
            this.ZaGodchart.Location = new System.Drawing.Point(614, 3);
            this.ZaGodchart.Name = "ZaGodchart";
            this.ZaGodchart.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Fire;
            series2.ChartArea = "ChartArea1";
            series2.Legend = "Legend1";
            series2.Name = "Series1";
            series2.XValueMember = "imyasotrudnika";
            series2.XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Double;
            series2.YValueMembers = "ZA GOD";
            this.ZaGodchart.Series.Add(series2);
            this.ZaGodchart.Size = new System.Drawing.Size(392, 309);
            this.ZaGodchart.TabIndex = 0;
            this.ZaGodchart.Text = "chart1";
            // 
            // tableBindingSource
            // 
            this.tableBindingSource.DataMember = "1Table";
            this.tableBindingSource.DataSource = this.financeDataSet1;
            // 
            // financeDataSet1
            // 
            this.financeDataSet1.DataSetName = "financeDataSet1";
            this.financeDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.chart1);
            this.tabPage2.Controls.Add(this.update);
            this.tabPage2.Controls.Add(this.ZaMesyatsChart);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1002, 348);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Диаграмма за месяц";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // update
            // 
            this.update.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.update.Location = new System.Drawing.Point(916, 318);
            this.update.Name = "update";
            this.update.Size = new System.Drawing.Size(80, 23);
            this.update.TabIndex = 2;
            this.update.Text = "Обновить";
            this.update.UseVisualStyleBackColor = true;
            this.update.Click += new System.EventHandler(this.update_Click);
            // 
            // ZaMesyatsChart
            // 
            chartArea4.Name = "ChartArea1";
            this.ZaMesyatsChart.ChartAreas.Add(chartArea4);
            this.ZaMesyatsChart.DataSource = this.tableBindingSource;
            legend4.Name = "Legend1";
            this.ZaMesyatsChart.Legends.Add(legend4);
            this.ZaMesyatsChart.Location = new System.Drawing.Point(546, 6);
            this.ZaMesyatsChart.Name = "ZaMesyatsChart";
            series4.ChartArea = "ChartArea1";
            series4.Legend = "Legend1";
            series4.Name = "Series1";
            series4.XValueMember = "imyasotrudnika";
            series4.YValueMembers = "ZA Mesyats";
            this.ZaMesyatsChart.Series.Add(series4);
            this.ZaMesyatsChart.Size = new System.Drawing.Size(450, 306);
            this.ZaMesyatsChart.TabIndex = 0;
            this.ZaMesyatsChart.Text = "ZaMesyatsChart";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn,
            this.imyasotrudnikaDataGridViewTextBoxColumn,
            this.familyasotrudnikaDataGridViewTextBoxColumn,
            this.otchestvosotrudnikaDataGridViewTextBoxColumn,
            this.zAGODDataGridViewTextBoxColumn,
            this.zAMesyatsDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.tableBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(12, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(545, 245);
            this.dataGridView1.TabIndex = 5;
            this.dataGridView1.DoubleClick += new System.EventHandler(this.dataGridView1_DoubleClick);
            // 
            // idDataGridViewTextBoxColumn
            // 
            this.idDataGridViewTextBoxColumn.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn.HeaderText = "Id";
            this.idDataGridViewTextBoxColumn.Name = "idDataGridViewTextBoxColumn";
            this.idDataGridViewTextBoxColumn.ReadOnly = true;
            this.idDataGridViewTextBoxColumn.Visible = false;
            // 
            // imyasotrudnikaDataGridViewTextBoxColumn
            // 
            this.imyasotrudnikaDataGridViewTextBoxColumn.DataPropertyName = "imyasotrudnika";
            this.imyasotrudnikaDataGridViewTextBoxColumn.HeaderText = "Имя";
            this.imyasotrudnikaDataGridViewTextBoxColumn.Name = "imyasotrudnikaDataGridViewTextBoxColumn";
            // 
            // familyasotrudnikaDataGridViewTextBoxColumn
            // 
            this.familyasotrudnikaDataGridViewTextBoxColumn.DataPropertyName = "familyasotrudnika";
            this.familyasotrudnikaDataGridViewTextBoxColumn.HeaderText = "Фамилия";
            this.familyasotrudnikaDataGridViewTextBoxColumn.Name = "familyasotrudnikaDataGridViewTextBoxColumn";
            // 
            // otchestvosotrudnikaDataGridViewTextBoxColumn
            // 
            this.otchestvosotrudnikaDataGridViewTextBoxColumn.DataPropertyName = "otchestvosotrudnika";
            this.otchestvosotrudnikaDataGridViewTextBoxColumn.HeaderText = "Отчество";
            this.otchestvosotrudnikaDataGridViewTextBoxColumn.Name = "otchestvosotrudnikaDataGridViewTextBoxColumn";
            // 
            // zAGODDataGridViewTextBoxColumn
            // 
            this.zAGODDataGridViewTextBoxColumn.DataPropertyName = "ZA GOD";
            this.zAGODDataGridViewTextBoxColumn.HeaderText = "За год";
            this.zAGODDataGridViewTextBoxColumn.Name = "zAGODDataGridViewTextBoxColumn";
            // 
            // zAMesyatsDataGridViewTextBoxColumn
            // 
            this.zAMesyatsDataGridViewTextBoxColumn.DataPropertyName = "ZA Mesyats";
            this.zAMesyatsDataGridViewTextBoxColumn.HeaderText = "За месяц";
            this.zAMesyatsDataGridViewTextBoxColumn.Name = "zAMesyatsDataGridViewTextBoxColumn";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.LightCyan;
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.otchestvoTextBox);
            this.groupBox1.Controls.Add(this.familyaTextBox);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.Exportbutton);
            this.groupBox1.Controls.Add(this.Deletebutton);
            this.groupBox1.Controls.Add(this.addButton);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.textBox4);
            this.groupBox1.Controls.Add(this.zaMesyatsTextBox);
            this.groupBox1.Controls.Add(this.zaGodTextBox);
            this.groupBox1.Controls.Add(this.imyaTextBox);
            this.groupBox1.Location = new System.Drawing.Point(563, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(460, 245);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button1.Location = new System.Drawing.Point(0, 160);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(132, 23);
            this.button1.TabIndex = 17;
            this.button1.Text = "Калькулятор";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.Location = new System.Drawing.Point(289, 100);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(152, 16);
            this.label6.TabIndex = 16;
            this.label6.Text = "Отчетсво Сотрудника";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(135, 100);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(148, 16);
            this.label5.TabIndex = 15;
            this.label5.Text = "Фамилия Сотрудника";
            // 
            // otchestvoTextBox
            // 
            this.otchestvoTextBox.Location = new System.Drawing.Point(289, 119);
            this.otchestvoTextBox.Name = "otchestvoTextBox";
            this.otchestvoTextBox.Size = new System.Drawing.Size(152, 20);
            this.otchestvoTextBox.TabIndex = 14;
            // 
            // familyaTextBox
            // 
            this.familyaTextBox.Location = new System.Drawing.Point(138, 119);
            this.familyaTextBox.Name = "familyaTextBox";
            this.familyaTextBox.Size = new System.Drawing.Size(145, 20);
            this.familyaTextBox.TabIndex = 13;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(7, 16);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(55, 20);
            this.label4.TabIndex = 12;
            this.label4.Text = "Поиск";
            // 
            // Exportbutton
            // 
            this.Exportbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Exportbutton.Location = new System.Drawing.Point(289, 210);
            this.Exportbutton.Name = "Exportbutton";
            this.Exportbutton.Size = new System.Drawing.Size(152, 23);
            this.Exportbutton.TabIndex = 10;
            this.Exportbutton.Text = "Экспорт";
            this.Exportbutton.UseVisualStyleBackColor = true;
            this.Exportbutton.Click += new System.EventHandler(this.Exportbutton_Click);
            // 
            // Deletebutton
            // 
            this.Deletebutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Deletebutton.Location = new System.Drawing.Point(138, 209);
            this.Deletebutton.Name = "Deletebutton";
            this.Deletebutton.Size = new System.Drawing.Size(142, 24);
            this.Deletebutton.TabIndex = 8;
            this.Deletebutton.Text = "Удалить";
            this.Deletebutton.UseVisualStyleBackColor = true;
            this.Deletebutton.Click += new System.EventHandler(this.Deletebutton_Click);
            // 
            // addButton
            // 
            this.addButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.addButton.Location = new System.Drawing.Point(0, 210);
            this.addButton.Name = "addButton";
            this.addButton.Size = new System.Drawing.Size(132, 24);
            this.addButton.TabIndex = 7;
            this.addButton.Text = "Добавить";
            this.addButton.UseVisualStyleBackColor = true;
            this.addButton.Click += new System.EventHandler(this.addButton_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(286, 147);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 16);
            this.label3.TabIndex = 6;
            this.label3.Text = "За месяц";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(135, 147);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 16);
            this.label2.TabIndex = 5;
            this.label2.Text = "За год";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(7, 100);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(115, 16);
            this.label1.TabIndex = 4;
            this.label1.Text = "Имя Сотрудника";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(68, 18);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(373, 20);
            this.textBox4.TabIndex = 3;
            this.textBox4.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // zaMesyatsTextBox
            // 
            this.zaMesyatsTextBox.Location = new System.Drawing.Point(289, 163);
            this.zaMesyatsTextBox.Name = "zaMesyatsTextBox";
            this.zaMesyatsTextBox.Size = new System.Drawing.Size(152, 20);
            this.zaMesyatsTextBox.TabIndex = 2;
            // 
            // zaGodTextBox
            // 
            this.zaGodTextBox.Location = new System.Drawing.Point(138, 163);
            this.zaGodTextBox.Name = "zaGodTextBox";
            this.zaGodTextBox.Size = new System.Drawing.Size(142, 20);
            this.zaGodTextBox.TabIndex = 1;
            // 
            // imyaTextBox
            // 
            this.imyaTextBox.Location = new System.Drawing.Point(6, 119);
            this.imyaTextBox.Name = "imyaTextBox";
            this.imyaTextBox.Size = new System.Drawing.Size(126, 20);
            this.imyaTextBox.TabIndex = 0;
            // 
            // _1TableTableAdapter
            // 
            this._1TableTableAdapter.ClearBeforeFill = true;
            // 
            // chart1
            // 
            chartArea3.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea3);
            this.chart1.DataSource = this.tableBindingSource1;
            legend3.Name = "Legend1";
            this.chart1.Legends.Add(legend3);
            this.chart1.Location = new System.Drawing.Point(17, 12);
            this.chart1.Name = "chart1";
            series3.ChartArea = "ChartArea1";
            series3.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Pie;
            series3.Legend = "Legend1";
            series3.Name = "Series1";
            series3.XValueMember = "imyasotrudnika";
            series3.YValueMembers = "ZA Mesyats";
            this.chart1.Series.Add(series3);
            this.chart1.Size = new System.Drawing.Size(367, 300);
            this.chart1.TabIndex = 4;
            this.chart1.Text = "chart1";
            // 
            // tableBindingSource1
            // 
            this.tableBindingSource1.DataMember = "1Table";
            this.tableBindingSource1.DataSource = this.financeDataSet1;
            // 
            // chart2
            // 
            chartArea1.Name = "ChartArea1";
            this.chart2.ChartAreas.Add(chartArea1);
            this.chart2.DataSource = this.tableBindingSource1;
            legend1.Name = "Legend1";
            this.chart2.Legends.Add(legend1);
            this.chart2.Location = new System.Drawing.Point(3, 6);
            this.chart2.Name = "chart2";
            this.chart2.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Fire;
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Pie;
            series1.Legend = "Legend1";
            series1.Name = "Series1";
            series1.XValueMember = "imyasotrudnika";
            series1.YValueMembers = "ZA GOD";
            this.chart2.Series.Add(series1);
            this.chart2.Size = new System.Drawing.Size(367, 300);
            this.chart2.TabIndex = 5;
            this.chart2.Text = "chart2";
            // 
            // employers
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1024, 638);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.groupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "employers";
            this.Text = "Финансовая отчетность сотрудники";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.employers_FormClosed);
            this.Load += new System.EventHandler(this.employers_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ZaGodchart)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tableBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.financeDataSet1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ZaMesyatsChart)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tableBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button UpdateButton;
        private System.Windows.Forms.DataVisualization.Charting.Chart ZaGodchart;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.DataVisualization.Charting.Chart ZaMesyatsChart;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button Exportbutton;
        private System.Windows.Forms.Button Deletebutton;
        private System.Windows.Forms.Button addButton;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox zaMesyatsTextBox;
        private System.Windows.Forms.TextBox zaGodTextBox;
        private System.Windows.Forms.TextBox imyaTextBox;
        private financeDataSet1 financeDataSet1;
        private System.Windows.Forms.BindingSource tableBindingSource;
        private financeDataSet1TableAdapters._1TableTableAdapter _1TableTableAdapter;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox otchestvoTextBox;
        private System.Windows.Forms.TextBox familyaTextBox;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn imyasotrudnikaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn familyasotrudnikaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn otchestvosotrudnikaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn zAGODDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn zAMesyatsDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button update;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart2;
        private System.Windows.Forms.BindingSource tableBindingSource1;
    }
}