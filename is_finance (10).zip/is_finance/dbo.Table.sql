﻿CREATE TABLE [dbo].[Table]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [predpriyatie] NCHAR(10) NULL, 
    [ZA GOD] MONEY NULL, 
    [ZA Mesyats] MONEY NULL
	
)
