﻿using System;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Aviareici
{
    public partial class Menu : Form
    {
        public Menu()
        {
            InitializeComponent();
        }
        SqlConnection sqlCon = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\\Avia.mdf;Integrated Security=True;Connect Timeout=30");
        SqlDataAdapter adapter;
        SqlCommandBuilder commandBuilder;
        string sql = "SELECT * FROM Avia";
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "aviaDataSet.Vilet". При необходимости она может быть перемещена или удалена.
            this.viletTableAdapter.Fill(this.aviaDataSet.Vilet);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "aviaDataSet.Prodazha". При необходимости она может быть перемещена или удалена.
            this.prodazhaTableAdapter.Fill(this.aviaDataSet.Prodazha);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "aviaDataSet.Marshrut". При необходимости она может быть перемещена или удалена.
            this.marshrutTableAdapter.Fill(this.aviaDataSet.Marshrut);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "aviaDataSet.Aviareis". При необходимости она может быть перемещена или удалена.
            this.aviareisTableAdapter.Fill(this.aviaDataSet.Aviareis);
            dataGridView2.DataSource = aviaDataSet.Marshrut; 
            dataGridView3.DataSource = aviaDataSet.Vilet;
            dataGridView1.Columns[0].Visible = false;
            dataGridView2.Columns[0].Visible = false;
            dataGridView3.Columns[0].Visible = false;
            dataGridView4.Columns[0].Visible = false;
        }
        private void pictureBox2_Click(object sender, EventArgs e)
        {
            try
            {
                Reset(); // сброс текстбоксов таблица 1
                Reset1();
                dataGridView1.DataSource = aviaDataSet.Aviareis;
                dataGridView2.DataSource = aviaDataSet.Marshrut;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error message!");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Reset(); // сброс текстбоксов таблица 1
        }
        private void button2_Click(object sender, EventArgs e) // удаление данных из таблицы 1
        {
            try
            {
                if (sqlCon.State == ConnectionState.Closed)
                    sqlCon.Open();
                SqlCommand sqlCmd = new SqlCommand("AviareisDeletion", sqlCon);
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.Parameters.AddWithValue("@Id_Reis", textBox2.Text.Trim());
                sqlCmd.ExecuteNonQuery();
                aviareisTableAdapter.Update(aviaDataSet.Aviareis); // обновление таблицы 1
                aviareisTableAdapter.Fill(aviaDataSet.Aviareis);
                marshrutTableAdapter.Update(aviaDataSet.Marshrut); // обновление таблицы 2
                marshrutTableAdapter.Fill(aviaDataSet.Marshrut);
                MessageBox.Show("Deleted successfully!");
                Reset(); // сброс текстбоксов таблица 1
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error message!");
            }
        }

        private void button4_Click(object sender, EventArgs e) // Сохранить \ редактировать таблица 1
        {
            if (textBox2.Text == "" || textBox3.Text == "")
            {
                MessageBox.Show("Не все поля заполнены!"); // проверка на заполненность полей
            }
            else
            {
                try
                {
                    if (sqlCon.State == ConnectionState.Closed)
                        sqlCon.Open();
                    if (button4.Text == "Сохранить") // сохранение данных в таблицу 1
                    {
                        SqlCommand sqlCmd = new SqlCommand("AviareisAddOrEdit", sqlCon);
                        sqlCmd.CommandType = CommandType.StoredProcedure;
                        sqlCmd.Parameters.AddWithValue("@mode", "Add");
                        sqlCmd.Parameters.AddWithValue("@Id", 0);
                        sqlCmd.Parameters.AddWithValue("@Id_Reis", textBox2.Text.Trim());
                        sqlCmd.Parameters.AddWithValue("@Mesta", textBox3.Text.Trim());
                        sqlCmd.ExecuteNonQuery();
                        aviareisTableAdapter.Update(aviaDataSet.Aviareis); // обновление таблицы 1
                        aviareisTableAdapter.Fill(aviaDataSet.Aviareis);
                        marshrutTableAdapter.Update(aviaDataSet.Marshrut); // обновление таблицы 2
                        marshrutTableAdapter.Fill(aviaDataSet.Marshrut);
                        Reset(); // сброс текстбоксов таблица 1
                        MessageBox.Show("Saved successfully!");
                    }
                    else // редактирование данных из таблицы 1
                    {
                        SqlCommand sqlCmd = new SqlCommand("AviareisAddOrEdit", sqlCon);
                        sqlCmd.CommandType = CommandType.StoredProcedure;
                        sqlCmd.Parameters.AddWithValue("@mode", "Edit");
                        sqlCmd.Parameters.AddWithValue("@Id", dataGridView1.CurrentRow.Cells[0].Value.ToString());
                        sqlCmd.Parameters.AddWithValue("@Id_Reis", textBox2.Text.Trim());
                        sqlCmd.Parameters.AddWithValue("@Mesta", textBox3.Text.Trim());
                        sqlCmd.ExecuteNonQuery();
                        aviareisTableAdapter.Update(aviaDataSet.Aviareis); // обновление таблицы 1
                        aviareisTableAdapter.Fill(aviaDataSet.Aviareis);
                        marshrutTableAdapter.Update(aviaDataSet.Marshrut); // обновление таблицы 2
                        marshrutTableAdapter.Fill(aviaDataSet.Marshrut);
                        Reset(); // сброс текстбоксов для таблиц 2,3
                        MessageBox.Show("Updated successfully!");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error message!");
                }
                finally
                {
                    sqlCon.Close();
                }
            }
        }

        private void dataGridView1_DoubleClick(object sender, EventArgs e) // строки в текстбоксы из таблицы 1
        {
            if (dataGridView1.CurrentRow.Index != -1)
            {
                textBox2.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
                textBox3.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
                button4.Text = "Изменить";
                button2.Enabled = Enabled;
            }
        }
        void Reset() // сброс текстбоксов таблица 1
        {
            textBox2.Text = textBox3.Text = "";
            button4.Text = "Сохранить";
            button2.Enabled = false;
        }
        void Reset1() // сброс текстбоксов для таблиц 2,3
        {
            textBox4.Text = "";
            button3.Text = "Сохранить";
            button7.Enabled = false;
        }
        void Reset2() // сброс текстбоксов таблица 1
        {
            button5.Text = "Сохранить";
            button9.Enabled = false;
        }
        void Reset3() // сброс текстбоксов таблица 1
        {
            textBox1.Text = "";
            button10.Text = "Сохранить";
            button12.Enabled = false;
        }
        private void button7_Click(object sender, EventArgs e) // удаление данных из таблицы 2
        {
            try
            {
                if (sqlCon.State == ConnectionState.Closed)
                    sqlCon.Open();
                SqlCommand sqlCmd = new SqlCommand("MarshrutDeletion", sqlCon);
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.Parameters.AddWithValue("@Id", dataGridView2.CurrentRow.Cells[0].Value.ToString());
                sqlCmd.ExecuteNonQuery();
                aviareisTableAdapter.Update(aviaDataSet.Aviareis); // обновление таблицы 1
                aviareisTableAdapter.Fill(aviaDataSet.Aviareis);
                marshrutTableAdapter.Update(aviaDataSet.Marshrut); // обновление таблицы 2
                marshrutTableAdapter.Fill(aviaDataSet.Marshrut);
                MessageBox.Show("Deleted successfully!");
                Reset1(); // сброс текстбоксов для таблиц 
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error message!");
            }
        }

        private void button3_Click_1(object sender, EventArgs e) // Сохранить \ редактировать таблица 2
        {
            if (comboBox1.Text == "" || textBox4.Text == "")
            {
                MessageBox.Show("Не все поля заполнены!"); // проверка на заполненность полей
            }
            else
            {
                try
                {
                    if (sqlCon.State == ConnectionState.Closed)
                        sqlCon.Open();
                    adapter = new SqlDataAdapter(sql, sqlCon);
                    commandBuilder = new SqlCommandBuilder(adapter);
                    if (button3.Text == "Сохранить") // сохранение данных в таблицу 2
                    {
                        SqlCommand sqlCmd = new SqlCommand("MarshrutAddOrEdit", sqlCon);
                        sqlCmd.CommandType = CommandType.StoredProcedure;
                        sqlCmd.Parameters.AddWithValue("@mode", "Add");
                        sqlCmd.Parameters.AddWithValue("@Id", 0);
                        sqlCmd.Parameters.AddWithValue("@Reis", comboBox1.Text.Trim());
                        sqlCmd.Parameters.AddWithValue("@City", comboBox7.Text.Trim());
                        sqlCmd.Parameters.AddWithValue("@TimePoleta", textBox4.Text.Trim());
                        string newFlight = comboBox1.Text;
                        string newCity = comboBox7.Text;

                        // Проверка на дублирование в источнике данных AviaDataSet
                        DataRow[] rowsWithSameFlight = aviaDataSet.Marshrut.Select($"Reis = '{newFlight}'");
                        foreach (DataRow row in rowsWithSameFlight)
                        {
                            if (row["City"].ToString() == newCity)
                            {
                                MessageBox.Show("Дублирование маршрута. Город не может быть указан дважды для одного рейса.");
                                return;
                            }
                        }
                        sqlCmd.ExecuteNonQuery();
                        aviareisTableAdapter.Update(aviaDataSet.Aviareis); // обновление таблицы 1
                        aviareisTableAdapter.Fill(aviaDataSet.Aviareis);
                        marshrutTableAdapter.Update(aviaDataSet.Marshrut); // обновление таблицы 2
                        marshrutTableAdapter.Fill(aviaDataSet.Marshrut);
                        Reset1(); // сброс текстбоксов для таблиц 
                        MessageBox.Show("Saved successfully!");
                    }
                    else // редактирование данных из таблицы 2
                    {
                        SqlCommand sqlCmd = new SqlCommand("MarshrutAddOrEdit", sqlCon);
                        sqlCmd.CommandType = CommandType.StoredProcedure;
                        sqlCmd.Parameters.AddWithValue("@mode", "Edit");
                        sqlCmd.Parameters.AddWithValue("@Id", dataGridView2.CurrentRow.Cells[0].Value.ToString());
                        sqlCmd.Parameters.AddWithValue("@Reis", comboBox1.Text.Trim());
                        sqlCmd.Parameters.AddWithValue("@City", comboBox7.Text.Trim());
                        sqlCmd.Parameters.AddWithValue("@TimePoleta", textBox4.Text.Trim());
                        string newFlight = comboBox1.Text;
                        string newCity = comboBox7.Text;

                        // Проверка на дублирование в источнике данных AviaDataSet
                        DataRow[] rowsWithSameFlight = aviaDataSet.Marshrut.Select($"Reis = '{newFlight}'");
                        foreach (DataRow row in rowsWithSameFlight)
                        {
                            if (row["City"].ToString() == newCity)
                            {
                                MessageBox.Show("Дублирование маршрута. Город не может быть указан дважды для одного рейса.");
                                return;
                            }
                        }
                        sqlCmd.ExecuteNonQuery();
                        aviareisTableAdapter.Update(aviaDataSet.Aviareis); // обновление таблицы 1
                        aviareisTableAdapter.Fill(aviaDataSet.Aviareis);
                        marshrutTableAdapter.Update(aviaDataSet.Marshrut); // обновление таблицы 2
                        marshrutTableAdapter.Fill(aviaDataSet.Marshrut);
                        Reset1();
                        MessageBox.Show("Updated successfully!");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error message!");
                }
                finally
                {
                    sqlCon.Close();
                }
            }
        }

        private void button6_Click(object sender, EventArgs e) // сброс текстбоксов для таблиц 
        {
            Reset1();
        }
        private void dataGridView3_DoubleClick(object sender, EventArgs e) // строки в текстбоксы из таблицы 3
        {
            if (dataGridView3.CurrentRow.Index != -1)
            {
                comboBox2.Text = dataGridView3.CurrentRow.Cells[1].Value.ToString();
                dateTimePicker1.Text = dataGridView3.CurrentRow.Cells[2].Value.ToString();
                dateTimePicker2.Text = dataGridView3.CurrentRow.Cells[3].Value.ToString();
                button5.Text = "Изменить";
                button9.Enabled = Enabled;
            }
        }
        private void dataGridView2_DoubleClick(object sender, EventArgs e) // строки в текстбоксы из таблицы 2
        {
            if (dataGridView2.CurrentRow.Index != -1)
            {
                comboBox1.Text = dataGridView2.CurrentRow.Cells[1].Value.ToString();
                comboBox7.Text = dataGridView2.CurrentRow.Cells[2].Value.ToString();
                textBox4.Text = dataGridView2.CurrentRow.Cells[3].Value.ToString();
                button3.Text = "Изменить";
                button7.Enabled = Enabled;
            }
        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e) // кнопка выхода из программы
        {
            Application.Exit();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (comboBox2.Text == "" || dateTimePicker1.Text == "" || dateTimePicker2.Text == "")
            {
                MessageBox.Show("Не все поля заполнены!"); // проверка на заполненность полей
            }
            else
            {
                try
                {
                    if (sqlCon.State == ConnectionState.Closed)
                        sqlCon.Open();
                    adapter = new SqlDataAdapter(sql, sqlCon);
                    commandBuilder = new SqlCommandBuilder(adapter);
                    if (button5.Text == "Сохранить") // сохранение данных в таблицу 3
                    {
                        SqlCommand sqlCmd = new SqlCommand("ViletAddOrEdit", sqlCon);
                        sqlCmd.CommandType = CommandType.StoredProcedure;
                        sqlCmd.Parameters.AddWithValue("@mode", "Add");
                        sqlCmd.Parameters.AddWithValue("@Id", 0);
                        sqlCmd.Parameters.AddWithValue("@Reis", comboBox2.Text.Trim());
                        sqlCmd.Parameters.AddWithValue("@DateVileta", DateTime.Parse(dateTimePicker1.Text));
                        sqlCmd.Parameters.AddWithValue("@TimeVileta", DateTime.Parse(dateTimePicker2.Text));
                        sqlCmd.ExecuteNonQuery();
                        viletTableAdapter.Update(aviaDataSet.Vilet); // обновление таблицы 3
                        viletTableAdapter.Fill(aviaDataSet.Vilet);
                        prodazhaTableAdapter.Update(aviaDataSet.Prodazha); // обновление таблицы 4
                        prodazhaTableAdapter.Fill(aviaDataSet.Prodazha);
                        Reset2(); // сброс текстбоксов для таблиц 
                        MessageBox.Show("Saved successfully!");
                    }
                    else // редактирование данных из таблицы 3
                    {
                        SqlCommand sqlCmd = new SqlCommand("ViletAddOrEdit", sqlCon);
                        sqlCmd.CommandType = CommandType.StoredProcedure;
                        sqlCmd.Parameters.AddWithValue("@mode", "Edit");
                        sqlCmd.Parameters.AddWithValue("@Id", dataGridView3.CurrentRow.Cells[0].Value.ToString());
                        sqlCmd.Parameters.AddWithValue("@Reis", comboBox2.Text.Trim());
                        sqlCmd.Parameters.AddWithValue("@DateVileta", DateTime.Parse(dateTimePicker1.Text));
                        sqlCmd.Parameters.AddWithValue("@TimeVileta", DateTime.Parse(dateTimePicker2.Text));
                        sqlCmd.ExecuteNonQuery();
                        viletTableAdapter.Update(aviaDataSet.Vilet); // обновление таблицы 3
                        viletTableAdapter.Fill(aviaDataSet.Vilet);
                        prodazhaTableAdapter.Update(aviaDataSet.Prodazha); // обновление таблицы 4
                        prodazhaTableAdapter.Fill(aviaDataSet.Prodazha);
                        Reset2();
                        MessageBox.Show("Updated successfully!");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error message!");
                }
                finally
                {
                    sqlCon.Close();
                }
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            try
            {
                if (sqlCon.State == ConnectionState.Closed)
                    sqlCon.Open();
                SqlCommand sqlCmd = new SqlCommand("ViletDeletion", sqlCon);
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.Parameters.AddWithValue("@Id", dataGridView3.CurrentRow.Cells[0].Value.ToString());
                sqlCmd.ExecuteNonQuery();
                viletTableAdapter.Update(aviaDataSet.Vilet); // обновление таблицы 3
                viletTableAdapter.Fill(aviaDataSet.Vilet);
                prodazhaTableAdapter.Update(aviaDataSet.Prodazha); // обновление таблицы 4
                prodazhaTableAdapter.Fill(aviaDataSet.Prodazha);
                Reset2();
                MessageBox.Show("Deleted successfully!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error message!");
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (comboBox3.Text == "" || dateTimePicker4.Text == "" || textBox1.Text == "")
            {
                MessageBox.Show("Не все поля заполнены!"); // проверка на заполненность полей
            }
            else
            {
                try
                {
                    if (sqlCon.State == ConnectionState.Closed)
                        sqlCon.Open();
                    adapter = new SqlDataAdapter(sql, sqlCon);
                    commandBuilder = new SqlCommandBuilder(adapter);
                    if (button10.Text == "Сохранить") // сохранение данных в таблицу 4
                    {
                        SqlCommand sqlCmd = new SqlCommand("ProdazhaAddOrEdit", sqlCon);
                        sqlCmd.CommandType = CommandType.StoredProcedure;
                        sqlCmd.Parameters.AddWithValue("@mode", "Add");
                        sqlCmd.Parameters.AddWithValue("@Id", 0);
                        sqlCmd.Parameters.AddWithValue("@Reis", comboBox3.Text.Trim());
                        sqlCmd.Parameters.AddWithValue("@DateVileta", DateTime.Parse(dateTimePicker4.Text));
                        sqlCmd.Parameters.AddWithValue("@FIO", textBox1.Text.Trim());
                        sqlCmd.ExecuteNonQuery();
                        viletTableAdapter.Update(aviaDataSet.Vilet); // обновление таблицы 3
                        viletTableAdapter.Fill(aviaDataSet.Vilet);
                        prodazhaTableAdapter.Update(aviaDataSet.Prodazha); // обновление таблицы 4
                        prodazhaTableAdapter.Fill(aviaDataSet.Prodazha);
                        Reset3(); // сброс текстбоксов для таблиц 
                        MessageBox.Show("Saved successfully!");
                    }
                    else // редактирование данных из таблицы 4
                    {
                        SqlCommand sqlCmd = new SqlCommand("ProdazhaAddOrEdit", sqlCon);
                        sqlCmd.CommandType = CommandType.StoredProcedure;
                        sqlCmd.Parameters.AddWithValue("@mode", "Edit");
                        sqlCmd.Parameters.AddWithValue("@Id", dataGridView4.CurrentRow.Cells[0].Value.ToString());
                        sqlCmd.Parameters.AddWithValue("@Reis", comboBox3.Text.Trim());
                        sqlCmd.Parameters.AddWithValue("@DateVileta", DateTime.Parse(dateTimePicker4.Text));
                        sqlCmd.Parameters.AddWithValue("@FIO", textBox1.Text.Trim());
                        sqlCmd.ExecuteNonQuery();
                        viletTableAdapter.Update(aviaDataSet.Vilet); // обновление таблицы 3
                        viletTableAdapter.Fill(aviaDataSet.Vilet);
                        prodazhaTableAdapter.Update(aviaDataSet.Prodazha); // обновление таблицы 4
                        prodazhaTableAdapter.Fill(aviaDataSet.Prodazha);
                        Reset3();
                        MessageBox.Show("Updated successfully!");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error message!");
                }
                finally
                {
                    sqlCon.Close();
                }
            }
        }

        private void button12_Click(object sender, EventArgs e)
        {
            try
            {
                if (sqlCon.State == ConnectionState.Closed)
                    sqlCon.Open();
                SqlCommand sqlCmd = new SqlCommand("ProdazhaDeletion", sqlCon);
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.Parameters.AddWithValue("@Id", dataGridView4.CurrentRow.Cells[0].Value.ToString());
                sqlCmd.ExecuteNonQuery();
                viletTableAdapter.Update(aviaDataSet.Vilet); // обновление таблицы 3
                viletTableAdapter.Fill(aviaDataSet.Vilet);
                prodazhaTableAdapter.Update(aviaDataSet.Prodazha); // обновление таблицы 4
                prodazhaTableAdapter.Fill(aviaDataSet.Prodazha);
                MessageBox.Show("Deleted successfully!");
                Reset3(); // сброс текстбоксов для таблиц
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error message!");
            }
        }

        private void dataGridView4_DoubleClick(object sender, EventArgs e)
        {
            if (dataGridView4.CurrentRow.Index != -1)
            {
                comboBox3.Text = dataGridView4.CurrentRow.Cells[1].Value.ToString();
                dateTimePicker4.Text = dataGridView4.CurrentRow.Cells[2].Value.ToString();
                textBox1.Text = dataGridView4.CurrentRow.Cells[3].Value.ToString();
                button10.Text = "Изменить";
                button12.Enabled = Enabled;
            }
        }

        private void button11_Click(object sender, EventArgs e)
        {
            Reset3();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Reset2();
        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (comboBox4.SelectedIndex)
            {
                case 0:
                    dataGridView2.Sort(dataGridView2.Columns[3], ListSortDirection.Ascending);
                    break;
                case 1:
                    dataGridView2.Sort(dataGridView2.Columns[3], ListSortDirection.Descending);
                    break;
            }
        }

        private void button13_Click(object sender, EventArgs e)
        {
            // Получаем выбранный город из ComboBox
            string selectedCity = comboBox5.SelectedItem.ToString();

            // Получаем таблицу данных из набора данных
            DataTable dataTable = aviaDataSet.Marshrut;

            // Создаем новую таблицу для хранения отфильтрованных данных
            DataTable filteredData = dataTable.Clone();

            // Фильтруем исходную таблицу по выбранному городу
            DataRow[] rows = dataTable.Select($"City = '{selectedCity}'");

            // Копируем отфильтрованные строки в новую таблицу
            foreach (DataRow row in rows)
            {
                filteredData.ImportRow(row);
            }

            // Сортируем новую таблицу по возрастанию времени полета
            DataView sortedView = filteredData.DefaultView;
            sortedView.Sort = "TimePoleta"; // Замените Время_полета на имя столбца времени полета
            filteredData = sortedView.ToTable();

            // Выводим отфильтрованные и отсортированные данные в DataGridView
            dataGridView2.DataSource = filteredData;
        }

        private void button14_Click(object sender, EventArgs e)
        {
            if (comboBox6.Text == "")
            {
                MessageBox.Show("Не все поля заполнены!"); // проверка на заполненность полей
            }
            else
            {
                // Получение выбранной даты и города из соответствующих элементов управления
                DateTime selectedDate = dateTimePicker5.Value.Date;
                string selectedCity = comboBox6.SelectedItem.ToString();

                // Фильтрация данных о маршрутах по выбранному городу
                DataRow[] filteredRoutes = aviaDataSet.Marshrut.Select($"City = '{selectedCity}'");
                if (filteredRoutes.Length == 0)
                {
                    MessageBox.Show("Нет доступных маршрутов для выбранного города.", "Предупреждение", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                // Нахождение ближайшего вылета для указанной даты
                DateTime nearestDepartureTime = DateTime.MaxValue;
                string nearestFlightId = string.Empty;

                foreach (DataRow routeRow in filteredRoutes)
                {
                    string flightId = routeRow["Reis"].ToString();
                    DataRow[] departureRows = aviaDataSet.Vilet.Select($"[Reis] = '{flightId}'");

                    foreach (DataRow departureRow in departureRows)
                    {
                        DateTime departureDate = ((DateTime)departureRow["DateVileta"]).Date;

                        if (departureDate == selectedDate && departureDate < nearestDepartureTime)
                        {
                            nearestDepartureTime = departureDate;
                            nearestFlightId = flightId;
                        }
                    }
                }

                if (string.IsNullOrEmpty(nearestFlightId))
                {
                    MessageBox.Show("Нет доступных вылетов для указанной даты и города.", "Предупреждение", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return;
                }

                // Вывод информации о ближайшем вылете
                string message = $"Ближайший вылет ({selectedCity}):" + Environment.NewLine +
                                 $"ID рейса: {nearestFlightId}" + Environment.NewLine +
                                 $"Дата вылета: {nearestDepartureTime.ToShortDateString()}";


                MessageBox.Show(message, "Информация о ближайшем вылете", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void button15_Click(object sender, EventArgs e)
        {
            dataGridView2.DataSource = aviaDataSet.Marshrut;
        }

        private void comboBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = (char)Keys.None;
        }

        private void comboBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = (char)Keys.None;
        }

        private void comboBox5_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = (char)Keys.None;
        }

        private void comboBox6_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = (char)Keys.None;
        }

        private void comboBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = (char)Keys.None;
        }

        private void comboBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = (char)Keys.None;
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;
            if (!Char.IsDigit(number) && number != 8)
            {
                e.Handled = true;
            }
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            char number = e.KeyChar;
            if (!Char.IsDigit(number) && number != 8)
            {
                e.Handled = true;
            }
        }

        private void comboBox7_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = (char)Keys.None;
        }

        private void comboBox8_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Получаем выбранный объект DataRowView из ComboBox
            DataRowView selectedRow = (DataRowView)comboBox8.SelectedItem;

            if (selectedRow != null)
            {
                // Извлекаем значение Id рейса из выбранного объекта DataRowView
                int selectedFlightId = Convert.ToInt32(selectedRow[0]);

                // Выполняем запрос к источнику данных для подсчета количества билетов
                DataRow[] selectedRows = aviaDataSet.Prodazha.Select("Reis = " + selectedFlightId);

                // Получаем количество билетов
                int ticketCount = selectedRows.Length;

                // Отображаем количество билетов в Label
                label30.Text = "Количество билетов: " + ticketCount.ToString();
            }
            else
            {
                label30.Text = "Выберите рейс";
            }
        }

        private void comboBox8_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.KeyChar = (char)Keys.None;
        }
        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void comboBox7_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker5_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}
